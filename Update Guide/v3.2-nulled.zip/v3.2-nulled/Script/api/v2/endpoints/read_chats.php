<?php
Wo_MarkAllChatsAsRead($wo['user']['user_id']);
$response_data = array(
                    'api_status' => 200
                );