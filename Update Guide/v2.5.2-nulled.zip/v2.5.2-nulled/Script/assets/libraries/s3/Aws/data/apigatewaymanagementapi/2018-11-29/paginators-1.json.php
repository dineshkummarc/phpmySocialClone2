<?php
// This file was auto-generated from sdk-root/src/data/apigatewaymanagementapi/2018-11-29/paginators-1.json
return [ 'pagination' => [],];
