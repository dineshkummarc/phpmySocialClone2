<?php
// This file was auto-generated from sdk-root/src/data/kendra/2019-02-03/paginators-1.json
return [ 'pagination' => [ 'ListDataSourceSyncJobs' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListDataSources' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListIndices' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
