<?php
// This file was auto-generated from sdk-root/src/data/cur/2017-01-06/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'DescribeReportDefinitions', 'input' => [], 'errorExpectedFromService' => false, ], ],];
