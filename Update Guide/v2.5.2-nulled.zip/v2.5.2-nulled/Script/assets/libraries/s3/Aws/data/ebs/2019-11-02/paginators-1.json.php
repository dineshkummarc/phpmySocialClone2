<?php
// This file was auto-generated from sdk-root/src/data/ebs/2019-11-02/paginators-1.json
return [ 'pagination' => [ 'ListChangedBlocks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListSnapshotBlocks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
